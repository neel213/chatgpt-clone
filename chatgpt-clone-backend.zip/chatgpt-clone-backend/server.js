import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config(); // Load environment variables from .env file

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.post('/api/chat', async (req, res) => {
    const userMessage = req.body.message;

    try {
        // Check if the OPENAI_API_KEY is set in the environment variables
        if (!process.env.OPENAI_API_KEY) {
            throw new Error('OpenAI API key is missing. Please set the OPENAI_API_KEY in your .env file.');
        }

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo', // Change the model to one you have access to
                messages: [{ role: 'user', content: userMessage }]
            }),
        });

        if (!response.ok) {
            const errorDetails = await response.json();
            throw new Error(`Error from OpenAI API: ${response.statusText}. Details: ${JSON.stringify(errorDetails)}`);
        }

        const data = await response.json();

        // OpenAI's API response format
        const chatbotResponse = data.choices[0].message.content || "Unable to retrieve a valid response from chatbot.";
        res.json({ message: chatbotResponse });
    } catch (error) {
        console.error('Error communicating with the OpenAI API:', error);
        res.status(500).json({ error: 'Internal Server Error', details: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
